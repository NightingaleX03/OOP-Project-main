/*
I declare that this submission is the result of my own work and I only copied the code that 
my professor provided to complete my workshops and assignments. This submitted piece of work 
has not been shared with any other student or 3rd party content provider.

Sarah Mathew
smathew32@myseneca.ca
140903238
*/

#include "Workstation.h"

namespace seneca{

    //initialize the deques
    std::deque<CustomerOrder> pending;
    std::deque<CustomerOrder> completed;
    std::deque<CustomerOrder> incomplete;

    //constructor
    Workstation::Workstation(const std::string& str) : Station(str){}

    void Workstation::fill(std::ostream& os){
        //if the order is not empty
        if(!m_orders.empty()){
            //fill the item in the order
            m_orders.front().fillItem(*this,os);
        }
    }
    bool Workstation::attemptToMoveOrder(){
        bool flag = false;
        
        //if the order is empty
        if(m_orders.empty()){
            flag = false;
        }
        
        //if the order is not empty
        else{

            //if the order is filled or the quantity is 0
            if(m_orders.front().isItemFilled(getItemName()) || getQuantity() == 0){

                //if the next station is not empty
                if(m_pNextStation != nullptr){
                    //move the order to the next station
                    *m_pNextStation += std::move(m_orders.front());
                }

                //if the next station is empty
                else{
                    //if the order is filled
                    if(m_orders.front().isItemFilled(getItemName())){
                        //move the order to the completed deque
                        completed.push_back(std::move(m_orders.front()));
                    }
                    //if the order is not filled
                    else{
                        //move the order to the incomplete deque
                        incomplete.push_back(std::move(m_orders.front()));
                    }
                }

                //remove the order from the deque
                m_orders.pop_back();
                flag = true;
            }
        }

        //return the flag
        return flag;
    }

    void Workstation::setNextStation(Workstation* station){
        //set the next station
        m_pNextStation = station;
    }

    Workstation* Workstation::getNextStation() const{
        //return the next station
        return m_pNextStation;
    }

    void Workstation::display(std::ostream& os) const{
        //display the item name and the next station
        os << getItemName() << " --> ";

        //if the next station is not empty
        if(m_pNextStation){
            os << m_pNextStation->getItemName();
        }
        //if the next station is empty
        else{
            os << "End of Line";
        }

        os << std::endl;
    }

    Workstation& Workstation::operator+=(CustomerOrder&& newOrder){
        //add the order to the deque
        m_orders.push_back(std::move(newOrder));
        return *this;
    }
}