/*
I declare that this submission is the result of my own work and I only copied the code that 
my professor provided to complete my workshops and assignments. This submitted piece of work 
has not been shared with any other student or 3rd party content provider.

Sarah Mathew
smathew32@myseneca.ca
140903238
*/

#include "LineManager.h"

namespace seneca{

    LineManager::LineManager(const std::string& file, std::vector<Station*>& station, std::vector<size_t>& index){
        
        std::ifstream fileStream(file);
        if(!fileStream){
            throw std::string("Unable to open [") + file + "] file.";
        }

        std::string line;
        while(std::getline(fileStream, line)){
            size_t pos = line.find('|');

            //finds the station in the station vector
            std::string stationName = line.substr(0, pos);

            //finds the next station in the station vector
            std::string nextStationName = (pos != std::string::npos) ? line.substr(pos + 1) : "";

            //finds the station in the station vector
            auto stationItr = std::find_if(station.begin(), station.end(), [&](Station* station){
                return station->getItemName() == stationName;
            });

            //finds the next station in the station vector
            if(stationItr != station.end()){
                

                if(!next.empty()){
                    auto nextStationItr = std::find_if(station.begin(), station.end(), [&](Station* station){
                        return station->getItemName() == nextStationName;
                    });

                    //if the next station is found
                    if(nextStationItr != station.end()){
                        //set the next station
                        (*stationItr)->setNextStation(*nextStationItr);
                    }
                }
            }
        }

        m_firstStation = *std::find_if(station.begin(), station.end(), [&](Station* station){
            return std::none_of(index.begin(), index.end(), [&](size_t i){
                return station->getItemName() == station->getItemName();
            });
        });
    }


    void LineManager::reorderStations(){
        
        std::vector<Workstation*> order;
        Workstation* current = m_firstStation;

        // move the stations to the order vector
        while(current != nullptr){
            order.push_back(current);
            current = current->getNextStation();
        }

        //move the order to the active line
        m_activeLine = std::move(order);
    }

    bool LineManager::run(std::ostream& os){
        static size_t count = 0;

        os << "Line Manager Iteration: " << ++count << std::endl;

        //if the pending deque is not empty
        if(!pending.empty()){
            //move the order to the first station
            *m_firstStation += std::move(pending.front());
            //remove the order from the pending deque
            pending.pop_front();
        }

        //fill the order
        for(auto& Workstation : m_activeLine){
            Workstation->fill(os);
        }

        //attempt to move the order
        for(auto& Workstation : m_activeLine){
            Workstation->attemptToMoveOrder();
        }

        //display the order
        return completed.size() + incomplete.size() == m_cntCustomerOrder;
    }

    void LineManager::display(std::ostream& os) const{
        //display the order
        for(auto& Workstation : m_activeLine){
            Workstation->display(os);
        }
    }
}